//Nurettin Hakan Sinal 220315099
package q2;

import java.util.ArrayList;
import java.util.List;

public class Q2 {
    
        public static void main(String[] args) {
        List<Integer> L1 = List.of(0, 2, 4, 6, 8); // L1 adında bir liste oluşturur ve değerlerini atar
        List<Integer> L2 = List.of(1, 3, 5, 7, 9); // L2 adında bir liste oluşturur ve değerlerini atar
        List<Integer> unionList = Union(L1, L2); // L1 ve L2 listelerinin birleşimini oluşturan metodu çağırır


        System.out.println("Union List: " + unionList); // Birleşim listesini ekrana yazdırır
    }

public static List<Integer> Union(List<Integer> L1, List<Integer> L2) {
        // Birleşim listesini tutacak ArrayList'i oluşturur
        List<Integer> unionList = new ArrayList<>();
        // Birleşim listesini tutacak ArrayList'i oluşturur
        int i = 0, j = 0;
        
        // L1 ve L2 listelerinin elemanlarını karşılaştırarak birleşim listesini oluşturur
        while (i < L1.size() && j < L2.size()) {
            if (L1.get(i) < L2.get(j)) {
                unionList.add(L1.get(i)); // L1'den elemanı birleşim listesine ekler
                i++; // L1 indeksini artırır
            } else if (L1.get(i) > L2.get(j)) {
                unionList.add(L2.get(j)); // L2'den elemanı birleşim listesine ekler
                j++; // L2 indeksini artırır
            } else {
                unionList.add(L1.get(i)); // Her iki listede de aynı eleman varsa bir tanesini birleşim listesine ekler
                i++; // L1 indeksini artırır
                j++; // L2 indeksini artırır
            }
        }

        // L1'de kalan elemanları birleşim listesine ekler        
        while (i < L1.size()) {
            unionList.add(L1.get(i));
            i++;
        }

        // L2'de kalan elemanları birleşim listesine ekler        
        while (j < L2.size()) {
            unionList.add(L2.get(j));
            j++;
        }
        
        // Oluşturulan birleşim listesini döndürür
        return unionList;
    }

}