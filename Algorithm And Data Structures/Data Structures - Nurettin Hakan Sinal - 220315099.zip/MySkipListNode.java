//Nurettin Hakan Sinal 220315099
package q1;

// MySkipListNode sınıfı, MySkipList'te kullanılacak düğümleri temsil eder
public class MySkipListNode {
   
    int value; // Düğümün değeri
    MySkipListNode[] next; // Düğümün bir sonraki düğümlere olan referansları

    // MySkipListNode sınıfının kurucu methodu    
    public MySkipListNode(int value, int level) {
        this.value = value;
        this.next = new MySkipListNode[level + 1]; // Düğümün seviye sayısına göre bir sonraki düğümlere yer açılır
    }
    
}