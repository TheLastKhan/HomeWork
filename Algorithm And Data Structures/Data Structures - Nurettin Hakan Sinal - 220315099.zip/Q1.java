//Nurettin Hakan Sinal 220315099
package q1;

import java.util.Random;

public class Q1 {

    public static void main(String[] args) {
        
        // MySkipList sınıfını kullanarak bir örnek oluşturuyoruz
        MySkipList mySkipList = new MySkipList();
        
        // MySkipList'e elemanlar ekliyoruz
        mySkipList.add(7);
        mySkipList.add(11);
        mySkipList.add(15);
        mySkipList.add(22);
        mySkipList.add(25);
        mySkipList.add(30);
        mySkipList.add(42);
        mySkipList.add(53);

        // MySkipList'te belirli bir değeri arıyoruz ve sonucu ekrana yazdırıyoruz
        System.out.println(mySkipList.search(11)); // Output: true
        System.out.println(mySkipList.search(99)); // Output: false
        
    }
    
}