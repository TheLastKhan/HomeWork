//Nurettin Hakan Sinal 220315099
package q4;

import java.util.Stack;

public class Q4 {

public static void main(String[] args) {
        String expression = "3 + 7 * 5 - 9 / 3"; // Bir matematiksel ifade tanımlar
        double result = calculateValue(expression); // İfadeyi değerlendirir ve sonucu alır
        System.out.println("Result: " + result); // Sonucu ekrana yazdırır
    }

    public static double calculateValue(String expression) {
        
        // Operandları tutacak bir Double stack'i ve operatörleri tutacak bir Character stack'i oluşturur
        Stack<Double> operandStack = new Stack<>();
        Stack<Character> operatorStack = new Stack<>();

        // İfadeyi karakter karakter gezer        
        for (int i = 0; i < expression.length(); i++) {
            char ch = expression.charAt(i);

            // Boşluk karakterini atlar
            if (ch == ' ') {
                continue;
                
            // Operatörleri işler
            } else if (ch == '+' || ch == '-' || ch == '*' || ch == '/') {
                
                // Operatörlerin önceliği kontrol edilir ve gerekirse işlem yapılır    
                while (!operatorStack.isEmpty() && hasPrecedence(ch, operatorStack.peek())) {
                    double operand2 = operandStack.pop();
                    double operand1 = operandStack.pop();
                    char operator = operatorStack.pop();
                    double result = performOperation(operand1, operand2, operator);
                    operandStack.push(result);
                }
                
                // Şu anki operatörü stack'e ekler           
                operatorStack.push(ch);
                
                // Sayıları işler
            } else if (Character.isDigit(ch)) {
                
                // Sayıyı birleştirir
                StringBuilder sb = new StringBuilder();
                sb.append(ch);
                while (i + 1 < expression.length() && Character.isDigit(expression.charAt(i + 1))) {
                    sb.append(expression.charAt(i + 1));
                    i++;
                }
                
                // Sayıyı Double'a çevirir ve stack'e ekler
                double operand = Double.parseDouble(sb.toString());
                operandStack.push(operand);
            }
        }
        
        // Stack'teki operatörleri sırayla işler
        while (!operatorStack.isEmpty()) {
            double operand2 = operandStack.pop();
            double operand1 = operandStack.pop();
            char operator = operatorStack.pop();
            double result = performOperation(operand1, operand2, operator);
            operandStack.push(result);
        }
        
        // İfade sonucunu döndürür
        return operandStack.pop();
    }

    // Operatörlerin önceliğini kontrol eder
    public static boolean hasPrecedence(char operator1, char operator2) {
        if ((operator1 == '*' || operator1 == '/') && (operator2 == '+' || operator2 == '-')) {
            return false;
        }
        return true;
    }

    // İki operandı ve bir operatörü alarak işlemi gerçekleştirir    
    public static double performOperation(double operand1, double operand2, char operator) {
        switch (operator) {
            case '+':
                return operand1 + operand2;
            case '-':
                return operand1 - operand2;
            case '*':
                return operand1 * operand2;
            case '/':
                return operand1 / operand2;
            default:
                throw new IllegalArgumentException("Invalid operator: " + operator);
        }
    }  

}