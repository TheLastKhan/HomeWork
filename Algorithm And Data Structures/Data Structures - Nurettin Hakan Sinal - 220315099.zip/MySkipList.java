//Nurettin Hakan Sinal 220315099
package q1;

import java.util.Random;

// MySkipList sınıfı, skip list veri yapısını temsil eder
public class MySkipList {
    
    private static final double PROBABILITY = 0.5; // Yüksek olasılık, daha düşük seviye sayısına yol açar
    private MySkipListNode head; // Skip list'in başlangıç düğümü
    private int maxLevel; // En yüksek seviye (level) tutar
    private int size; // Skip list'in toplam eleman sayısı

    // MySkipList sınıfının kurucu methodu
    public MySkipList() {
        this.head = new MySkipListNode(Integer.MIN_VALUE, 0); // Başlangıç düğümü oluşturuluyor
        this.maxLevel = 0;
        this.size = 0;
    }

    // MySkipList'e eleman ekleyen method
    public void add(int value) {
        int level = randomLevel(); // Rastgele seviye (level) belirleyen methodu çağırıyoruz
        MySkipListNode newNode = new MySkipListNode(value, level); // Yeni bir düğüm oluşturuyoruz

        MySkipListNode[] update = new MySkipListNode[level + 1];
        for (int i = 0; i <= level; i++) {
            update[i] = head; // Güncelleme dizisini başlangıç düğümüyle dolduruyoruz
        }

        MySkipListNode current = head;
        // Her seviyedeki düğümleri güncelliyoruz
        for (int i = Math.min(maxLevel, current.next.length - 1); i >= 0; i--) {
            while (current.next[i] != null && current.next[i].value < value) {
                current = current.next[i];
            }
            if (i <= level) {
                newNode.next[i] = current.next[i];
                current.next[i] = newNode;
            }
        }
        // Eğer eklenen elemanın seviyesi mevcut en yüksek seviyeden büyükse, en yüksek seviyeyi güncelliyoruz
        if (level > maxLevel) {
            maxLevel = level;
        }
        size++; // Toplam eleman sayısını arttırıyoruz
    }
    
    // MySkipList'te belirli bir değeri arayan method
    public boolean search(int value) {
        MySkipListNode current = head;
        // Her seviyedeki düğümleri kontrol ediyoruz
        for (int i = Math.min(maxLevel, current.next.length - 1); i >= 0; i--) {
            while (current.next[i] != null && current.next[i].value < value) {
                current = current.next[i];
            }
        }
        current = current.next[0];
        // Aranan değeri bulduk mu kontrol ediyoruz
        return current != null && current.value == value;
    }

    // Rastgele seviye (level) belirleyen method
    private int randomLevel() {
        int level = 0;
        Random random = new Random();
        // Belirli bir olasılıkla seviye belirliyoruz
        while (random.nextDouble() < PROBABILITY && level < maxLevel + 1) {
            level++;
        }
        return level;
    }
    
}
