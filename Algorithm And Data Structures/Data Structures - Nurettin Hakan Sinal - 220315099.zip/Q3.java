//Nurettin Hakan Sinal 220315099
package q3;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Q3 {

public static void main(String[] args) {
            String filePath = "C:\\Users\\hakan\\OneDrive\\Belgeler\\NetBeansProjects\\Q3\\src\\q3\\test.txt"; // Dosyanın yolu

            try {
                Map<String, Integer> wordCountMap = new HashMap<>(); // Kelime sayısını tutacak HashMap'i oluşturur

                // Dosyayı okur
                BufferedReader reader = new BufferedReader(new FileReader(filePath));
                String line;

                // Satır satır okuma yapar
                while ((line = reader.readLine()) != null) {
                    // Satırı kelimelere ayırır
                    String[] words = line.split("\\s+");

                    // Her kelimeyi işler
                    for (String word : words) {
                        // Alfanumerik olmayan karakterleri kaldırır
                        word = word.replaceAll("[^a-zA-Z0-9]", "");

                       // Boş kelimeleri göz ardı eder
                        if (!word.isEmpty()) {
                            // Hash tablosundaki kelime sayısını günceller
                            wordCountMap.put(word, wordCountMap.getOrDefault(word, 0) + 1);
                        }
                    }
                }
                reader.close(); // BufferedReader'ı kapatır

                // Farklı kelime sayısını ekrana yazdırır
                int distinctWordCount = wordCountMap.size();
                System.out.println("Distinct word count: " + distinctWordCount);

                // En çok tekrar eden kelimeyi bulur
                String mostRepeatedWord = "";
                int maxCount = 0;
                for (Map.Entry<String, Integer> entry : wordCountMap.entrySet()) {
                    if (entry.getValue() > maxCount) {
                        mostRepeatedWord = entry.getKey();
                        maxCount = entry.getValue();
                    }
                }
                // En çok tekrar eden kelimeyi ve sayısını ekrana yazdırır
                System.out.println("Most repeated word: " + mostRepeatedWord);

            } catch (IOException e) {
                e.printStackTrace(); // IOException hatası durumunda hata mesajını ekrana yazdırır
            }
        }
    
}
